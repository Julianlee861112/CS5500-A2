This is assignment2 part2, written by Yu-Yang, Lee.

This package enable users to encode and decode range and complex datatype.

To install, type "python3 -m pip install jsonapi" in your terminal.
